using System;
using SplashKitSDK;
using System.Collections.Generic;

public class RobotDodge
{
    private Player _Player;
    private Window _GameWindow;

    private List<Robot> _Robots;
    public bool Quit
    {
        get
        {
            return _Player.Quit;
        }
    }
    private void CheckCollisions()
    {
        List<Robot> robotsToRemove = new List<Robot>();
        foreach (Robot robot in _Robots)
        {
            if (_Player.collidedWith(robot) || robot.IsOffscreen(_GameWindow))
            {
                robotsToRemove.Add(robot);
            }
        }
        foreach (Robot Remove in robotsToRemove)
        {
            _Robots.Remove(Remove);
        }
    }

    public RobotDodge(Window win)
    {
        _GameWindow = win;
        _Player = new Player(_GameWindow);
        _Robots = new List<Robot>();
        _Robots.Add(RandomRobot());
    }

    public void HandleInput()
    {
        _Player.HandleInput();
        _Player.StayOnWindow();
    }
    public void Update()
    {
        foreach (Robot robot in _Robots)
        {
            robot.Update();
        }
        CheckCollisions();
        if (SplashKit.Rnd(90) <= 5)
        { // ((60)<=X): add X robots per second  
            _Robots.Add(RandomRobot());
        }

    }


    public Robot RandomRobot()
    {
        int robot = SplashKit.Rnd(1, 4);

        switch (robot) {

        case 1:
            return new Roundy  (_GameWindow, _Player);

        case 2:
            return new Boxy (_GameWindow, _Player);
        case 3:
            return new echolong (_GameWindow, _Player);
        default:

            return null;
    }
    }


public void Draw()
{
    _GameWindow.Clear(Color.AliceBlue);

    foreach (Robot robot in _Robots)
    {
        robot.Draw();
    }
    _Player.Draw();
    _GameWindow.Refresh(60);

}
}