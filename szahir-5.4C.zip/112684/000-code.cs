using System;
using SplashKitSDK;
//Program class
public class Program
{
    //Starting of the Main method 
    public static void Main()
    {
        Window Robotecho;
        RobotDodge Dodgeecho;
        Robotecho = new Window("ManyRobots", 800, 600);
        Dodgeecho = new RobotDodge(Robotecho);

        while (!Dodgeecho.Quit && !Robotecho.CloseRequested)
        {
            SplashKit.ProcessEvents();
            Dodgeecho.HandleInput();
            Dodgeecho.Update();
            Dodgeecho.Draw();

        }
    }



}