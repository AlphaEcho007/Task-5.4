using System;
using SplashKitSDK;

public class Robot
{
    public double X
    {
        get;
        set;
    }
    private Window _gameWindow;
    private Vector2D Velocity
    {
        get; set;
    }
    public double Y
    {
        get;
        set;
    }

    private Color MainColor = Color.RandomRGB(200);

    public Circle collisionCircle
    {
        get
        {
            return SplashKit.CircleAt(X + 25, Y + 25, 20);
        }
    }
    public Robot(Window gameWindow, Player player)
    {

        _gameWindow = gameWindow;
        const int SPEED = 5;
        Point2D fromPt = new Point2D()
        {
            X = X,
            Y = Y
        };
        Point2D toPt = new Point2D()
        {
            X = player.X,
            Y = player.Y
        };

        Vector2D dir;
        dir = SplashKit.UnitVector(SplashKit.VectorPointToPoint(fromPt, toPt));
        Velocity = SplashKit.VectorMultiply(dir, SPEED);

        if (SplashKit.Rnd() < 0.5)
        {
            X = SplashKit.Rnd(gameWindow.Width);
            if (SplashKit.Rnd() < 0.5)
                Y = -Height;
            else
                Y = _gameWindow.Height;
        }
        else
        {
            Y = SplashKit.Rnd(gameWindow.Height);
            if (SplashKit.Rnd() < 0.5)
                X = +Width;
            else
                X = _gameWindow.Width;
        }
    }
    private int Width
    {
        get { return 50; }
    }

    private int Height
    {
        get { return 50; }
    }


    public bool IsOffscreen(Window screen)
    {
        if (X < -Width || X > screen.Width || Y < -Height || Y > screen.Height)
        {
            return true;
        }
        return false;

    }
    public void Draw()
    {

        double leftX = X + 12;
        double rightX = X + 27;
        double eyeY = Y + 10;
        double mouthY = Y + 30;

        _gameWindow.FillRectangle(Color.Gray, X, Y, 50, 50);
        _gameWindow.FillRectangle(MainColor, leftX, eyeY, 10, 10);
        _gameWindow.FillRectangle(MainColor, rightX, eyeY, 10, 10);
        _gameWindow.FillRectangle(MainColor, leftX, mouthY, 25, 10);
        _gameWindow.FillRectangle(MainColor, leftX + 2, mouthY + 2, 21, 6);
    }
    public void Update()
    {
        X = Velocity.X + X;
        Y = Velocity.Y + Y;
    }
}