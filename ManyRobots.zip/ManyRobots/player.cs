using System;
using SplashKitSDK;

public class Player {
    private Bitmap _PlayerBitmap;
    private double _x, _y; // to store the x position of the player
    private Window Game;
    private bool _Quit;

    public bool collidedWith (Robot _TestRobot) {
        return _PlayerBitmap.CircleCollision (X, Y, _TestRobot.collisionCircle);
    }

    public Player (Window window) {
        Game = window;
        Bitmap Player1 = new Bitmap ("Player", "Player.png");
        _PlayerBitmap = Player1;
        _x = (window.Width - Width) / 2; // defining the width of the player 
        _y = (window.Height - Height) / 2; // definig the height of the player together with the screen 
        _Quit = false;
    }

    public double X { // allow others outside the class to access 
        get { return _x; } // the player position read only 
        set { }
    }
    public double Y {
        get { return _y; }
        set { }
    }

    public int Width {
        get {
            return _PlayerBitmap.Width; // width of the player
        }
    }

    public int Height {
        get {
            return _PlayerBitmap.Height; // height of the player 
        }
    }

    public bool Quit {
        get {
            return _Quit;
        }
    }

    public void Draw () {

        SplashKit.DrawBitmap (_PlayerBitmap, _x, _y); // the player is drawn 
    }
    public void HandleInput () {
        const int spead = 5;

        if (SplashKit.KeyDown (KeyCode.UpKey)) {
            _y -= spead;
        }
        if (SplashKit.KeyDown (KeyCode.LeftKey)) {
            _x -= spead;
        }
        if (SplashKit.KeyDown (KeyCode.RightKey)) {
            _x += spead;
        }
        if (SplashKit.KeyDown (KeyCode.DownKey)) {
            _y += spead;
        }
        if (SplashKit.KeyDown (KeyCode.EscapeKey)) {
            _Quit = true;
        }
        StayOnWindow ();
    }

    public void StayOnWindow () {
        const int GAP = 10;

        if (X > Game.Width - GAP - Width) {
            _x = Game.Width - GAP - Width;
        }
        if (X < GAP)
            _x = GAP;
        if (Y > Game.Height - GAP - Height) {
            _y = Game.Height - GAP - Height;
        }
        if (Y < GAP) {
            _y = GAP;
        }
    }

}