using System;
using SplashKitSDK;
using System.Collections.Generic;

public class RobotDodge
{
    private Player _Player;
    private Window _GameWindow;

    private List<Robot> _Robots;
    public bool Quit
    {
        get
        {
            return _Player.Quit;
        }
    }
    private void CheckCollisions()
    {
        List<Robot> robotsToRemove = new List<Robot>();
        foreach (Robot robot in _Robots)
        {
            if (_Player.collidedWith(robot) || robot.IsOffscreen(_GameWindow))
            {
                robotsToRemove.Add(robot);
            }
        }
        foreach (Robot Remove in robotsToRemove)
        {
            _Robots.Remove(Remove);
        }
    }

    public RobotDodge(Window win)
    {
        _GameWindow = win;
        _Player = new Player(_GameWindow);
        _Robots = new List<Robot>();
        _Robots.Add(RandomRobot());
    }

    public void HandleInput()
    {
        _Player.HandleInput();
        _Player.StayOnWindow();
    }
    public void Update()
    {
        foreach (Robot robot in _Robots)
        {
            robot.Update();
        }
        CheckCollisions();
        if (SplashKit.Rnd(60) <= 1)
        { // ((60)<=X): add X robots per second  
            _Robots.Add(RandomRobot());
        }

    }


    public Robot RandomRobot()
    {
        Robot Robot = new Robot(_GameWindow, _Player);
        return Robot; // Gives out a new robot
    }

    public void Draw()
    {
        _GameWindow.Clear(Color.AliceBlue);

        foreach (Robot robot in _Robots)
        {
            robot.Draw();
        }
        _Player.Draw();
        _GameWindow.Refresh(60);

    }
}