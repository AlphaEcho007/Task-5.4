You can place files in this folder for the webserver to return.
