using System;
using SplashKitSDK;
//Program class
public class Program
{
    //Starting of the Main method 
    public static void Main()
    {
        Window Robot;
        RobotDodge Dodge;
        Robot = new Window("Game", 800, 600);
        Dodge = new RobotDodge(Robot);

        while (!Dodge.Quit && !Robot.CloseRequested)
        {
            SplashKit.ProcessEvents();
            Dodge.HandleInput();
            Dodge.Update();
            Dodge.Draw();

        }
    }



}